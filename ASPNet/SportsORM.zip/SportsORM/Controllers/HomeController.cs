﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.WomenLeagues = context.Leagues.Where(l => l.Name.Contains("Women")).ToList();
            ViewBag.HockeyLeagues = context.Leagues.Where( l => l.Sport.Contains("Hockey")).ToList();
            ViewBag.NotFootball = context.Leagues.Where(l => !l.Sport.Contains("Football")).ToList();
            ViewBag.Conferences = context.Leagues.Where(l => l.Name.Contains("Conference")).ToList();
            ViewBag.Atlantic = context.Leagues.Where(l => l.Name.Contains("Atlantic")).ToList();
            ViewBag.Dallas = context.Teams.Where(t => t.Location == "Dallas").ToList();
            ViewBag.Raptors = context.Teams.Where(t => t.TeamName.Contains("Raptors")).ToList();
            ViewBag.LocationCity = context.Teams.Where(t => t.Location.Contains("City")).ToList();
            ViewBag.TTeams = context.Teams.Where(t => t.TeamName.StartsWith('T'));
            ViewBag.LocationOrder = context.Teams.OrderBy(t => t.Location);
            ViewBag.LocationDescending = context.Teams.OrderByDescending(t => t.Location);
            ViewBag.Cooper = context.Players.Where(p => p.LastName =="Cooper").ToList();
            ViewBag.Josh = context.Players.Where(p => p.FirstName == "Joshua").ToList();
            ViewBag.NoJosh = context.Players.Where(p => p.LastName == "Cooper" && p.FirstName != "Joshua").ToList();
            ViewBag.AlexOrWyatt = context.Players.Where(p => p.FirstName == "Alexander" || p.FirstName == "Wyatt").ToList();
            
            
            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}