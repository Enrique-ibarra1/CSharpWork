using System;
using System.ComponentModel.DataAnnotations;
namespace Crudelicious.Models
{
    public class Dish
    {
        [Key]
        public int DishId {get;set;}

        [Required]
        public string Name {get;set;}
        [Required]
        public string Chef {get;set;}

        [Required]
        [Range(1,6)]
        public int Rating {get;set;}
        
        [Required]
        [Range(1,2500, ErrorMessage="No single dish can be over 2500 calories or less than 1")]
        public int Calories {get;set;}

        [Required]
        [MinLength(5, ErrorMessage="Please enter a lengthier description")]
        public string Description {get;set;}
        public DateTime CreatedAt {get;set;} = DateTime.Now;
        public DateTime UpdatedAt {get;set;} = DateTime.Now;


    }
}