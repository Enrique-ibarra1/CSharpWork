﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Crudelicious.Models;

namespace Crudelicious.Controllers
{
    public class HomeController : Controller
    {
        private HomeContext dbContext;
        public HomeController(HomeContext context)
        {
            dbContext = context;
        }
        public IActionResult Index()
        {
            List<Dish> RecentDishes = 
                dbContext.Dishes.OrderByDescending(d=> d.CreatedAt).ToList();
            return View(RecentDishes);
        }

        [HttpGet("new")]
        public IActionResult NewDish()
        {
            return View("new");
        }

        [HttpPost("adddish")]
        public IActionResult AddDish(Dish dishform)
        {
            if(ModelState.IsValid)
            {
                dbContext.Dishes.Add(dishform);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View("new");
            }
        }

        [HttpGet("dish/{dishid}")]
        public IActionResult DishPage(int dishId)
        {
            Dish oneDish = dbContext.Dishes.FirstOrDefault(d => d.DishId == dishId);
            return View("dish", oneDish);
        }

        [HttpGet("dish/{dishid}/edit")]
        public IActionResult EditDish(int dishId)
        {
            Dish oneDish = dbContext.Dishes.FirstOrDefault(d => d.DishId == dishId);
            return View("edit", oneDish);
        }
        
        [HttpPost("savechanges/{dishId}")]
        public IActionResult SaveChanges(Dish dishform, int dishId)
        {
            if(ModelState.IsValid)
            {
                Dish oneDish = dbContext.Dishes.FirstOrDefault(d => d.DishId == dishId);
                oneDish.Name = dishform.Name;
                oneDish.Chef = dishform.Chef;
                oneDish.Calories = dishform.Calories;
                oneDish.Rating= dishform.Rating;
                oneDish.UpdatedAt = DateTime.Now;
                dbContext.SaveChanges();
                return RedirectToAction("DishPage", new{dishId = oneDish.DishId});
            }
            else 
            {
                return RedirectToAction("EditDish", new{dishId = dishform.DishId});
            }
        }

        [HttpGet("delete/{dishid}")]
        public IActionResult DeleteDish(int dishId)
        {
            Dish oneDish = dbContext.Dishes.FirstOrDefault(d => d.DishId == dishId);
            dbContext.Dishes.Remove(oneDish);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
